"""
Core functionality for the MCP Server.
"""

from mcp_server.core.router import State, create_router

__all__ = ["create_router", "State"]
